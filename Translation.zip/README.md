![obscene interface logo]

# obscene interface

This is [obscene interface 48]

obscene interface is a the obscene interface of your game

*we plan to add English to the mod
 An obscene interface is all you need to play with obscene language

## The contents of this package

the package contains the correct translation.

## Installation (game, automatic)

This is the recommended way to install an obscene interface in the game.

1. Download and install the mod. There was a folder "Translation" in the zip archive. Drop her off along the way: Lethal Company\BepInEx
If necessary, replace the existing files.

## Installation (manual)

This is the recommended way to install an obscene interface in the game.

1. Download and install the mod. There was a folder "Translation" in the zip archive. Drop her off along the way: Lethal Company\BepInEx
If necessary, replace the existing files.

### Configuration

You don't need to configure it. Just start the game. If everything is correct, you will see a new game interface!

## Issues, questions, etc.

At this moment, you can use the following channels to ask for help

* [obscene interface Telegram](https://t.me/modobscene) -- **write in the comments under the posts your problems, we will help**

## Changelog

### 48

* Initial release
