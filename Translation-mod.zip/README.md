![obscene interface logo]

# obscene interface

This is [obscene interface 47]

obscene interface is a general purpose framework for Unity modding.
obscene interface includes tools and libraries for

* Upload custom code (hereinafter *plugins*) to the game at startup;
* Fix in-game methods, classes, and even entire assemblies without affecting the game's source files;
* Configure plugins and register the game in the desired output, such as a console or file;
* Manage plugin dependencies.

 An obscene interface is all you need to play with obscene language

## The contents of this package

the package contains the correct translation.

## Installation (game, automatic)

This is the recommended way to install an obscene interface in the game.

1. Download and install the mod. There was a folder "Translation" in the zip archive. Drop her off along the way: The Deadly Company\BepInEx
If necessary, replace the existing files.

## Installation (manual)

This is the recommended way to install an obscene interface in the game.

1. Download and install the mod. There was a folder "Translation" in the zip archive. Drop her off along the way: The Deadly Company\BepInEx
If necessary, replace the existing files.

### Configuration

You don't need to configure it. Just start the game. If everything is correct, you will see a new game interface!

## Issues, questions, etc.

At this moment, you can use the following channels to ask for help

* [obscene interface Telegram](https://t.me/modobscene) -- **write in the comments under the posts your problems, we will help**

## Changelog

### 47

* Initial release
